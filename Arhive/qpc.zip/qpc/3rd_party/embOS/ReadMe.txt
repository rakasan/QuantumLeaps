Dear embOS tester,
 

this embos trial version should serve as an "easy start" with embOS. 
All project pathes are relative to the project file.
You should therefore be able to copy the entire directory 
(including all subdirectories) to any location on your harddrive.
Please make sure all files are r/w.

The only limitation in embOS trial version is a time limit of 12 hours.
There is no functional limitation.
The embOS trial versions runs unlimited as long as only up to 
3 tasks are created. If more than three tasks were created, the system 
stops when the time limit exceeded.

You may only use the trial version in order to evaluate embOS for 
fitness for a particular purpose. Under no circumstances 
it may be used in a product. If you would like to use
embOS in a product, please get in touch with us:

Head office Germany
 Phone: +49-2103-2878-0
 Fax: +49-2103-2878-28
 E-mail: info@segger.com
 www.segger.com 

US office
 Phone: +1-978-874-0299
 Fax: +1-978-874-0599
 E-mail: info@segger-us.com
 www.segger-us.com 
 
(embOS is priced reasonably and is royalty-free)

 
Thank you for your fairness and trying out embOS !
